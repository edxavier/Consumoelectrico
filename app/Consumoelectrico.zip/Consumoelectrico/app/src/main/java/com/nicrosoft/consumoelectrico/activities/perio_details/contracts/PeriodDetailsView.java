package com.nicrosoft.consumoelectrico.activities.perio_details.contracts;

/**
 * Created by Eder Xavier Rojas on 01/12/2017.
 */

public interface PeriodDetailsView {
}
