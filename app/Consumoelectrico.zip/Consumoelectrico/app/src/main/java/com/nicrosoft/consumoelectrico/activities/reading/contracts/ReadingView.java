package com.nicrosoft.consumoelectrico.activities.reading.contracts;

/**
 * Created by Eder Xavier Rojas on 15/01/2017.
 */

public interface ReadingView {
    void showInfo(String msg);
    void showWarning(String msg);

}
