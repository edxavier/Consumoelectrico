package com.nicrosoft.consumoelectrico.fragments.main.contracts;


import android.support.annotation.Nullable;

import com.nicrosoft.consumoelectrico.realm.Lectura;
import com.nicrosoft.consumoelectrico.realm.Periodo;

import java.util.Date;
import java.util.List;

import io.realm.RealmResults;

/**
 * Created by Eder Xavier Rojas on 11/01/2017.
 */

public interface MainService {
    @Nullable
    Lectura getResumeData();
    RealmResults<Lectura> getHistoryReadings();
    boolean isRecordsEmpty();
    boolean thereIsRecordForDate(Date date);
    boolean endPeriod(Date date);
    Periodo getActivePeriod();

}
