package com.nicrosoft.consumoelectrico.fragments.readings.contracts;

import com.nicrosoft.consumoelectrico.realm.Lectura;

import io.realm.RealmResults;

/**
 * Created by Eder Xavier Rojas on 17/02/2017.
 */

public interface LecturasView {

    void setReadings(RealmResults<Lectura> results);
    void showEmptyMsg(boolean show);
}
