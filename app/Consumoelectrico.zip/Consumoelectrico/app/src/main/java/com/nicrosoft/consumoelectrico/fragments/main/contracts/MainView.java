package com.nicrosoft.consumoelectrico.fragments.main.contracts;


import com.nicrosoft.consumoelectrico.realm.Lectura;

import io.realm.RealmResults;

/**
 * Created by Eder Xavier Rojas on 11/01/2017.
 */

public interface MainView {
    void setResumeData(Lectura lectura, boolean afterSave);
    void setHistoryReadings(RealmResults<Lectura> lecturas);
    void showEmptyDataMsg();

}
